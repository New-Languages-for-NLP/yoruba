Yoruba pipeline optimized for CPU. Components: tok2vec, tagger, parser, senter, lemmatizer.

| Feature | Description |
| --- | --- |
| **Name** | `yo_yoruba_sm` |
| **Version** | `0.0.1` |
| **spaCy** | `>=3.3.0,<3.4.0` |
| **Default Pipeline** | `tok2vec`, `tagger`, `parser`, `ner` |
| **Components** | `tok2vec`, `tagger`, `parser`, `ner` |
| **Vectors** | 0 keys, 0 unique vectors (0 dimensions) |
| **Sources** | n/a |
| **License** | `MIT` |
| **Author** | [New Languages for NLP](https://newnlp.princeton.edu) |

### Label Scheme

<details>

<summary>View label scheme (7 labels for 3 components)</summary>

| Component | Labels |
| --- | --- |
| **`tagger`** | `-` |
| **`parser`** | `ROOT`, `dep` |
| **`ner`** | `DATE`, `LOC`, `ORG`, `PER` |

</details>

### Accuracy

| Type | Score |
| --- | --- |
| `TAG_ACC` | 100.00 |
| `DEP_UAS` | 0.00 |
| `DEP_LAS` | 0.00 |
| `DEP_LAS_PER_TYPE` | 0.00 |
| `SENTS_P` | 0.00 |
| `SENTS_R` | 0.00 |
| `SENTS_F` | 0.00 |
| `ENTS_F` | 30.73 |
| `ENTS_P` | 50.44 |
| `ENTS_R` | 22.09 |
| `TOK2VEC_LOSS` | 2796357.31 |
| `TAGGER_LOSS` | 0.00 |
| `PARSER_LOSS` | 0.00 |
| `NER_LOSS` | 65020.53 |