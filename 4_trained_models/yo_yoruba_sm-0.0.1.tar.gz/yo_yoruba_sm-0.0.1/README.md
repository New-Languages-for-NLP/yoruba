Yoruba pipeline optimized for CPU. Components: tok2vec, tagger, parser, senter, lemmatizer.

| Feature | Description |
| --- | --- |
| **Name** | `yo_yoruba_sm` |
| **Version** | `0.0.1` |
| **spaCy** | `>=3.3.0,<3.4.0` |
| **Default Pipeline** | `tok2vec`, `tagger`, `ner`, `trainable_lemmatizer`, `morphologizer` |
| **Components** | `tok2vec`, `tagger`, `ner`, `trainable_lemmatizer`, `morphologizer` |
| **Vectors** | 0 keys, 0 unique vectors (0 dimensions) |
| **Sources** | n/a |
| **License** | `MIT` |
| **Author** | [New Languages for NLP](https://newnlp.princeton.edu) |

### Label Scheme

<details>

<summary>View label scheme (110 labels for 3 components)</summary>

| Component | Labels |
| --- | --- |
| **`tagger`** | `-`, `ADJ`, `ADP`, `ADV`, `AUX`, `CCONJ`, `DET`, `INTJ`, `NOUN`, `NUM`, `PART`, `PRON`, `PROPN`, `PUNCT`, `SCONJ`, `SYM`, `VERB`, `X`, `_`, `prs`, `rel` |
| **`ner`** | `DATE`, `LOC`, `ORG`, `PER` |
| **`morphologizer`** | `POS=NOUN`, `POS=PUNCT`, `NumType=Card\|POS=NUM`, `POS=PROPN`, `Number=Plur \|POS=DET\|PronType=Dem`, `POS=PART`, `POS=ADP`, `POS=ADJ`, `POS=VERB`, `POS=CCONJ`, `POS=ADV`, `POS=AUX`, `POS=PRON\|PronType=Rel`, `Case=Nom\|Number=Sing\|POS=PRON\|Person=3\|PronType=Prs`, `Number=Plur\|POS=DET\|PronType=Ind`, `Case=Gen\|Number=Plur\|POS=PRON\|Person=1\|PronType=Prs`, `Case=Nom\|Number=Plur\|POS=PRON\|Person=3\|PronType=Prs`, `POS=ADV\|PronType=Int`, `Number=Plur\|POS=DET\|PronType=Dem`, `POS=PRON\|PronType=Ind`, `Case=Gen\|Number=Plur\|POS=PRON\|Person=3\|PronType=Prs`, `POS=SYM`, `Number=Plur\|POS=DET\|PronType=Tot`, `NumType=Mult\|POS=NUM`, `NumType=Ord\|POS=NUM`, `POS=SCONJ`, `POS=DET\|PronType=Dem`, `Number=Sing\|POS=PRON\|PronType=Dem`, `Case=Acc\|Number=Sing\|POS=PRON\|Person=3\|PronType=Prs`, `NumType=Ord\|POS=ADJ`, `Case=Nom\|Number=Plur\|POS=PRON\|Person=1\|PronType=Prs`, `Number=Sing\|POS=VERB\|PronType=Ind`, `POS=X`, `POS=VERB\|PronType=Rel`, `Case=Gen\|Number=Sing\|POS=PRON\|Person=3\|PronType=Prs`, `Case=Nom\|Number=Sing\|POS=PRON\|Person=1\|PronType=Prs`, `Case=Nom\|Number=Sing\|POS=PRON\|Person=2\|PronType=Prs`, `Case=Gen\|Number=Sing\|POS=PRON\|Person=2\|PronType=Prs`, `Case=Acc\|Number=Plur\|POS=PRON\|Person=3\|PronType=Prs`, `_`, `Case=Acc\|Number=Sing\|POS=PART\|Person=3\|PronType=Prs`, `POS=ADV\|PronType=Dem`, `POS=DET\|PronType=Emp`, `Case=Nom\|Number=Plur\|POS=PRON\|Person=2\|PronType=Prs`, `POS=PRON\|PronType=Int`, `Number=Plur\|POS=PRON\|PronType=Tot`, `Case=Gen\|Number=Sing\|POS=PRON\|Person=1\|PronType=Prs`, `Case=Acc\|Number=Sing\|POS=PRON\|Person=1\|PronType=Prs`, `Case=Acc\|Number=Plur\|POS=PRON\|Person=1\|PronType=Prs`, `POS=INTJ`, `POS=ADV\|PronType=Rel`, `POS=PRON\|PronType=Dem`, `Number=Sing\|POS=PRON\|PronType=Ind`, `Number=Plur\|POS=DET\|Prontype=Tot`, `Case=Acc\|Number=Sing\|POS=PRON\|Person=2\|PronType=Prs`, `Number=Sing\|POS=PRON\|Person=3\|PronType=Prs\|nCase=Acc`, `Case=Nom\|Number=Sing\|POS=PART\|Person=3\|PronType=Prs`, `POS=DET\|PronType=Int`, `POS=PRON`, `Case=Acc\|Number=Sing\|POS=PRON\|Person=3\|PronType=Ind`, `Number=Plur\|POS=PRON\|PronType=Dem`, `POS=DET\|PronType=Ind`, `POS=ADP\|PronType=Rel`, `POS=ADV\|Pron=Int`, `Number=Sing\|POS=DET\|PronType=Dem`, `NumType=Card\|POS=DET`, `POS=PART\|PronType=Rel`, `Number=Sing\|POS=ADP\|PronType=Ind`, `NumType=Card\|POS=ADJ`, `Case=Acc\|Number=SIng\|POS=PRON\|Person=3\|PronType=Prs`, `Case=Nom\|Number=Sing\|POS=PART\|Person=2\|PronType=Prs`, `POS=VERB\|PronType=Dem`, `Case=Nom\|Number=Plur\|POS=DET\|Person=3\|PronType=Prs`, `Case=Nom\|Number=Plur\|POS=DET\|Person=1\|PronType=Prs`, `Case=Gen\|Number=Plur\|POS=DET\|Person=1\|PronType=Prs`, `Case=Nom\|Number=Plural\|POS=PRON\|Person=1\|PronType=Prs`, `POS=DET`, `POS=AUX\|PronType=Rel`, `Number=Sing\|POS=PART\|PronType=Ind`, `Case=Gen\|Number=Plur\|POS=PRON\|Person=2\|PronType=Prs`, `Case=Nom\|Number=Sing\|POS=INTJ\|Person=1\|PronType=Prs`, `Case=Nom\|Number=Sing\|POS=SCONJ\|Person=3\|PronType=Int`, `NumType=Dist\|POS=NUM`, `POS=NOUN\|PronType=Ind`, `Case=Gen\|Number=Plur\|POS=PRON\|Person=3\|PronType=Pr` |

</details>

### Accuracy

| Type | Score |
| --- | --- |
| `TAG_ACC` | 71.28 |
| `ENTS_F` | 0.00 |
| `ENTS_P` | 0.00 |
| `ENTS_R` | 0.00 |
| `LEMMA_ACC` | 47.36 |
| `POS_ACC` | 84.91 |
| `MORPH_ACC` | 92.72 |
| `ENTS_ACC` | 0.00 |
| `DEP_UAS` | 0.00 |
| `DEP_LAS` | 0.00 |
| `DEP_LAS_PER_TYPE` | 0.00 |
| `SENTS_P` | 0.00 |
| `SENTS_R` | 0.00 |
| `SENTS_F` | 0.00 |
| `TOK2VEC_LOSS` | 849411282.98 |
| `TAGGER_LOSS` | 2296224.81 |
| `NER_LOSS` | 141743.91 |
| `TRAINABLE_LEMMATIZER_LOSS` | 2140964.99 |
| `MORPHOLOGIZER_LOSS` | 218353.61 |